//// swift-tools-version:5.5
//import PackageDescription
//
//let package = Package(
//    name: "NoteShare",
//    platforms: [
//        .iOS(.v14)
//    ],
//    dependencies: [
//        .package(url: "https://github.com/onevcat/Kingfisher.git", from: "7.0.0"),
//        .package(url: "https://github.com/hyperoslo/Cache.git", from: "6.0.0")
//    ],
//    targets: [
//        .target(
//            name: "NoteShare",
//            dependencies: ["Kingfisher", "Cache"]
//        )
//    ]
//) 
